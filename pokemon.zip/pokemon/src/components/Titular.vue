<template>
    <div>
        <h1>
            {{ titular }}
        </h1> 
        <h4>Esta guía devuelve algunas de las características principales del personaje</h4> 
    </div>
</template>

<script>
export default {
    name: 'titular',
    data() {
        return {
            titular: 'PokeGuía',
        }
    },
}
</script>

<style scoped>

</style>