<template>
  <!--<img alt="Vue logo" src="./assets/logo.png">
  <HelloWorld msg="Welcome to Your Vue.js App"/>-->
  <div>
    <Titular></Titular>
    <div>
      <img v-bind:src="logo" alt="pokelogo" class="imagen">
    </div>

    Nombre <input type="text" id="info" v-model="nombre"> <button @click="pokemon">Buscar</button>
    <p>El personaje es <b>{{this.nombre}}</b></p>
    <img v-bind:src="pokeimg" :alt="nombre">

    <h2>Movimientos</h2>

    <p>
      {{movimientos}}
    </p>


    <h2>Habilidades</h2>

    <p>
      {{habilidades}}
    </p>
  </div>
</template>

<script>
/*import HelloWorld from './components/HelloWorld.vue'*/
import Titular from './components/Titular.vue'

export default {
  name: 'App',
  components: {
    Titular
  },// fin components
  data() {
    return {
      pokemones: [],
      nombre: 'pikachu',
      dato:'',
      logo: "https://programacion.net/files/article/20170428010447_pokemon.jpg",
      pokeimg: '',
      movimientos: [],
      habilidades: [],
    }
  },//fin data
  //component property van antes del método
  
  methods: {
    async pokemon() {
      const url = 'https://pokeapi.co/api/v2/';
      //let nombre = this.nombre;
      //console.log('este ' + nombre);
      try {
        const pokeData = await fetch(`${url}pokemon/${this.nombre}`);
        const pokemon = await pokeData.json();
        //console.log(pokemon);
        //console.log('otro ' + pokemon.name);
        //nombre = pokemon.name;
        //console.log('este si es ' + nombre);
        //
        let mov = pokemon.moves[0].move.name;
        let imagen = pokemon.sprites.front_default;
        let hab = pokemon.abilities[0].ability.name;
        //
        this.pokeimg = imagen;
        //console.log(imagen);
        //console.log('estos son los movimientos ' + mov);
        //console.log('estas son las habilidades ' + hab);
        this.movimientos = mov;
        this.habilidades = hab;
      } catch(error) {
        console.error('Sito no encontrado', error);
      }
    },

    buscar: function(){
      //this.pokemones.push(this.nombre);
      //console.log(this.pokemones);
      //this.nombre = '';
    }
  },// fin methods

  created() {
    this.pokemon();
  },// fin created

  mounted(){
    this.pokeUrl;
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
  display: grid;
}
img {
  grid-row: 3;
  width: 25%;
  height: 25%;
}
</style>
